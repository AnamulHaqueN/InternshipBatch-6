
const form = document.querySelector('.task-form') as HTMLFormElement;

const title = document.querySelector('#title') as HTMLInputElement;

const description = document.querySelector('#description') as HTMLInputElement;

const assignedUser = document.querySelector('#assigned-user') as HTMLInputElement;

const div = document.querySelector('#task');

let taskArr = localStorage.getItem('taskArr');

form.addEventListener('submit', (e: Event) => {
  e.preventDefault();
    const ul = document.createElement('ul');
    let att = document.createAttribute("class");
    att.value = "display";
    ul.setAttributeNode(att);
    let TaskData = {
        title: title.value,
        description: description.value,
        assignedUser: assignedUser.value
    }
    
    localStorage.setItem('taskArr', JSON.stringify(TaskData));
    alert('Form data saved to localStorage!');
    ul.innerHTML = `
       <li><b>Title</b>: ${TaskData.title}</li>
       <li>Description: ${TaskData.description}</li>
       <li>Assigned User: ${TaskData.assignedUser}</li>
       <button id="start-task">start task</button>
    `
    div?.appendChild(ul);
    //console.log(TaskData);
    
});
const getTask = localStorage.getItem("userData");
console.log(getTask);





